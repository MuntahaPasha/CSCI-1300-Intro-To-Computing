#include "SpellChecker.h"
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

SpellChecker::SpellChecker()
{
    //Default constructor taking only these parameters
    start_marker = '~';
    end_marker = '~';
    language="English";
}

SpellChecker::SpellChecker(string name)
{
    //Constructor with only string, takes the same parameters as the default constructor
    start_marker = '~';
    end_marker = '~';
    language=name;
}

SpellChecker::SpellChecker(string lang, string validfile, string correctword)
{
    //Parameters for this constructor, which include
    validword=validfile;
    invalidword=correctword;
    start_marker = '~';
    end_marker = '~';
    language = lang;
    readValidWords(validword);
    readCorrectedWords(invalidword);

}

SpellChecker::~SpellChecker()
{

}

bool SpellChecker::readValidWords(string filename)
{
    string temp;
    ifstream inputfile;
    inputfile.open(filename);

    if(!inputfile.is_open())
    {
        return false;
    }

    while(!inputfile.eof())
    {
        getline(inputfile, temp);
        validwords[counter]=temp;
        counter++;
        //cout<<temp<<endl;
    }

    return true;
}

int SpellChecker::findCorrectWord(string word)
{
    for(int i=0; i<10000; i++)
    {
        if(wordArray[i][0]==word)
        {
            return i;
        }
    }
    return -1;
}

int Split(string str, char separate, string words[], int max_size)
    {
        int count = 1;
        int indexarray = 0;
        if(str=="")
       {
            return 0;
        }
      for(int index=0; index<str.length(); index++)
        {
       if(str[index]==separate)
       {
           words[indexarray]=str.substr(0, index);
           str.erase(0, (index+1));
           indexarray++;
           count++;
           index =0;
       }

        }

   words[indexarray]=str;

   return count;
    }

bool SpellChecker::readCorrectedWords(string correctedwords)
{
   string line;
    ifstream inputfile;
    inputfile.open(correctedwords);

    if(!inputfile.is_open())
    {
        return false;
    }

    while(!inputfile.eof())
    {
        string tempArray[2];
        getline(inputfile, line);
        Split(line, '\t', tempArray, 2);

        wordArray[rows][columns]=tempArray[0];
        columns++;
        wordArray[rows][columns]=tempArray[1];
        rows++;
        columns=0;
        //cout<<tempArray[0]<<" "<<tempArray[1]<<endl;
    }

    return true;
}

bool SpellChecker::setStartMarker(char begin)
{
    start_marker=begin;
}

char SpellChecker::getStartMarker()
{
    return start_marker;
}

bool SpellChecker::setEndMarker(char end)
{
    end_marker=end;
}
char SpellChecker::getEndMarker()
{
    return end_marker;
}


bool SpellChecker::checkPunctuation(char c)
{
    char punctuation[]={'?', ',', '.','!','\'','"','!', ':', ';'};
    for(int i=0; i<sizeof(punctuation); i++)
    {
        if(c==punctuation[i])
        {
            return true;
        }
    }
        return false;
}

string SpellChecker::removePunctuation(string line)
{
 string newline;
 for (int j = 0; j < line.length(); j++)
 {
  char c = tolower(line[j]);
  bool shouldIgnore = false;
  if (checkPunctuation(c))
  {
   bool isLineEdge = (j == 0 || j == line.length() - 1); // Check either end of line
   bool hasSpaceNextToIt = j == 0 ? false : j == line.length() - 1 ? false : line[j - 1] == ' ' ? true : line[j + 1] == ' ' ? true : false;
   if (hasSpaceNextToIt || isLineEdge)
   {
    shouldIgnore = true;
   }
  }

  if (!shouldIgnore)
  {
   newline += c;
  }
 }

 return newline;
}

/*string SpellChecker::removePunctuation(string line)
{
    string newline;
    for(int j=0; j<line.length(); j++)
    {
        char m = tolower(line[j]);
    if(!checkPunctuation(m))
    {
        newline=newline+m;
    }
    }

    return newline;
}*/

/*bool isPunctuation = checkPunctuation(m);
        bool nextCharIsSpace = false;
        bool prevCharIsSpace = false;

        if (j < (line.length()-1))
        {
        nextCharIsSpace = line[j + 1] == ' ';
        }
        if (j > 0)
        {
            prevCharIsSpace = line[j - 1] == ' ';
        }
        if (isPunctuation)
        {
            if (!(nextCharIsSpace && prevCharIsSpace))
            {
            newline = newline + m;
            }
        }
        else
        {
            newline = newline + m;
        }

    }
 return newline;*/


bool SpellChecker::checkValidWord(string word)
{
    for(int i=0; i<10000; i++)
    {
        if(validwords[i]==word)
        {
            return true;
        }
    }
    return false;
}

string SpellChecker::marker(string word)
{
    return start_marker+word+end_marker;
}

string SpellChecker::repair(string line)
{
    string temparray[200];
    string repairedsentence;
    string newsentence=removePunctuation(line);

    int wordcount= Split(newsentence, ' ', temparray, 200);

    for(int i=0; i<wordcount; i++)
    {
        if(checkValidWord(temparray[i])==true)
        {
            repairedsentence=repairedsentence+temparray[i];
        }
        else
        {   int pos=findCorrectWord(temparray[i]);
            if(pos!=-1)
            {
                repairedsentence=repairedsentence+wordArray[pos][1];
            }
            else
            {
                repairedsentence=repairedsentence+marker(temparray[i]);
            }
        }
        repairedsentence=repairedsentence+" ";
    }
        return repairedsentence;

}



