// Author: Muntaha Pasha
// Recitation: 204, Camilla
//
// Assignment 3
// Problem 2

#include <iostream>
#include <cmath>

using namespace std;

/**
* Algorithm description:
*
*
*
*
*/
float windChillCalculator(float T, float V)
{
    float windChill;
    windChill = 35.74 + 0.6215*T - 35.75*(pow(V,0.16)) + 0.4275*T*(pow(V,0.16));
    return windChill;
}

void printwindChill(float T, float low_wind_speed, float high_wind_speed, float wind_speed_step)
{

    float windChill;


    while(low_wind_speed <= high_wind_speed)
        {
            windChill = windChillCalculator(T, low_wind_speed);
            low_wind_speed = low_wind_speed+wind_speed_step;
            cout<<"The wind chill is "<<windChill<<" degrees F for an air temperature of "<<T<<" and a wind speed of "<<low_wind_speed<<"mph."<<endl;
        }

}


int main(void)
{
    float T;
    float V;
    float windChill;
    float low_wind_speed;
    float high_wind_speed;
    float wind_speed_step;
    cout<<"Input Temperature: "<<endl;
    cin>>T;
    cout<<"Input Wind Speed: "<<endl;
    cin>>V;
    windChill = windChillCalculator(T, V);

    cout<<"The wind chill is "<<windChill<<" degrees F."<<endl;

    cout<<"Enter low wind speed: "<<endl;
    cin>>low_wind_speed;
    cout<<"Enter high wind speed: "<<endl;
    cin>>high_wind_speed;
    cout<<"Enter wind speed step: "<<endl;
    cin>>wind_speed_step;

    printwindChill(T, low_wind_speed, high_wind_speed, wind_speed_step);
}
