#ifndef SpellChecker_H
#define SpellChecker_H

#include <iostream>
using namespace std;

class SpellChecker
{
    public:
        SpellChecker();
        ~SpellChecker();

        string language;
        string validword;
        string invalidword;
        int counter=0; //setting counter for readvalidwords in the .h so that in the .cpp it'll always use the current value of counter

        SpellChecker(string);

        SpellChecker(string, string validwords, string invalidwords);

          bool readValidWords(string filename);

          bool readCorrectedWords(string correctedwords);

          bool setStartMarker(char begin);
          char getStartMarker();
          bool setEndMarker(char end);
          char getEndMarker();

          string removePunctuation(string sentence);

          string repair(string sentence);
          bool checkPunctuation(char);

    private:
        char start_marker;
        char end_marker;
        string validwords[10000];

  string wordArray[10000][2];
  int rows=0;
  int columns=0;

  int findCorrectWord(string word);
  bool checkValidWord(string word);
  string marker(string word);
};

#endif
