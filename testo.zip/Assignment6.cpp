// Muntaha Pasha: CS1300 Fall 2017
// Recitation: – Camilla, 204
//
// Assignment 6

#include <iostream>
#include <math.h>
#include <fstream>
#include <string>

using namespace std;

/*
 *ifstream to open filename, and then filenme.open
 *If statement, that determines if the file has opened or not, with a return value of -1
 *Variable for the sentences to be read will be "String sentence;"
 *Then we will read each sentence line by line using getline(file, sentence)
 *float value to store the count of the total chars, so float total; and float avg; to caclulate average
 *Store the line in an int line variable
 *for(line=0; !filename.eof; line++)
 *If you see a character, increment the total chars variable.
  a) totalchars= totalchars+sentence.length()
  b) when we exit the loop we will have count of all characters in the file
 *after loop has exited, the formula to find the average will be totalchars/line
 *Function will return that as a float. You will set a float variable to contain totalchars/line, and then return that.
*/

float avgCharsPerLine(string filename)
{
    ifstream tempfile;
    tempfile.open(filename.c_str(), ios::in);

        /*if(!tempfile.open())
        {
        cout<<"Unable to open file"<<endl;
        return -1;
        }*/

        string sentence;
        float linelength=0;
        float counter=0;

        while(!tempfile.eof())
        {
            getline(tempfile, sentence);
            counter ++;
            linelength=linelength+sentence.length();
        }

        float result = linelength/counter;

        tempfile.close();

        return result;
}

/*
 *
*/

int Split(string str, char separate, string words[], int max_size)
    {
        int count = 1;
        int indexarray = 0;
        if(str=="")
       {
            return 0;
        }
      for(int index=0; index<str.length(); index++)
        {
       if(str[index]==separate)
       {
           words[indexarray]=str.substr(0, index);
           str.erase(0, (index+1));
           indexarray++;
           count++;
           index =0;
       }

        }

   words[indexarray]=str;

   return count;
    }


int fillArray(string filename, float array[][5])
{
    ifstream tempfile;
    tempfile.open(filename.c_str(), ios::in);
    string sentence;
    getline(tempfile, sentence);
       int j=0;
       int index=0;

    while(getline(tempfile, sentence))
    {
        string temparray[5];
        Split(sentence, ',', temparray,5);

        for(j=0; j<5; j++)
        {
            array[index][j]=stof(temparray[j]);
        }
        index++;
    }
    tempfile.close();
     return index;
}


float arrayStats(string filename, float numbers[][5])
{
    int rows= fillArray(filename, numbers);
    float mean_value=0;
    float other_mean=0;

    for(int i=1; i<5; i+=2) //starts at one and goes up 2 because 1 is odd
    {
        float counter=0;
        for(int j=0; j<rows; j++)
        {
              counter=counter+numbers[j][i];

        }
        mean_value=mean_value+(counter/rows);
    }
    for(int i=1; i<rows; i+=2)

       {
           float sum=0;
        for(int j=0; j<5; j++)
        {
            sum=sum+numbers[i][j];

        }
        other_mean= other_mean+(sum/5);
    }

    float total= mean_value+other_mean;
    return total;
}

int search(string users[100], string name)
{
    for(int index=0; index<100; index++) //for loop looking through index
    {
        if(users[index]==name) //if you see the target value in the index, then...
        {
            return index; //return this value to us!
        }
    }

    return 999; //otherwise if you look through entire array and you don't see a target value, then return -1.
}

void addBookRatings(string filename, string users[], int ratings[][50])
{
    ifstream tempfile;
    tempfile.open(filename.c_str(), ios::in);

    if(tempfile.is_open())
    {   string sentence;
        getline(tempfile, sentence);
        int usersarrayindex=0;
        while(getline(tempfile, sentence))
        {
            string tempArray[3];
        Split(sentence,',',tempArray, 3);
        int x=search(users, tempArray[0]);
            if(x==999)
            {
                    users[usersarrayindex]=tempArray[0];
                    x=usersarrayindex;
                    usersarrayindex++;
            }
            int something=stoi(tempArray[1]);
                ratings[x][something]=stoi(tempArray[2]);

            }
        }

}





