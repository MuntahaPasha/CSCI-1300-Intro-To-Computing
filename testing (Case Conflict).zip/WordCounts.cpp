#include "WordCounts.h"
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

WordCounts::WordCounts()
{
	index = 0;
	temp = 0;

	for(int i=0; i<10000; i++)
    {
        wording[i]="";
        counting[i]=0;
    }
}

WordCounts::~WordCounts()
{

}

bool WordCounts::checkPunctuation(char c)
{
	char punctuation[] = { '?', ',', '.','!','\'','"','!', ':', ';' };
	for (int i = 0; i<sizeof(punctuation); i++)
	{
		if (c == punctuation[i])
		{
			return true;
		}
	}
	return false;
}


string WordCounts::removePunctuation(string line)
{
	string newline;
	for (int j = 0; j<line.length(); j++)
	{
		char m = tolower(line[j]);
		if (!checkPunctuation(m))
		{
			newline = newline + m;
		}
	}
	return newline;
}

int WordCounts::Split(string str, char separate, string words[], int max_size)
{
	int count = 1;
	int indexarray = 0;
	if (str == "")
	{
		return 0;
	}
	for (int index = 0; index<str.length(); index++)
	{
		if (str[index] == separate)
		{
			words[indexarray] = str.substr(0, index);
			str.erase(0, (index + 1));
			indexarray++;
			count++;
			index = 0;
		}

	}

	words[indexarray] = str;

	return count;
}

bool WordCounts::checkWords(string word)
{

	for (int i = 0; i<index; i++)
	{
		if (wording[i] == word)
		{
			temp = i;
			return true;
		}
	}
	return false;
}

void WordCounts::tallyWords(string inputsentence)
{
	int size = 0;
	string tempArray[10000];
	string inputsentence_nopunc = removePunctuation(inputsentence);

	size = Split(inputsentence_nopunc, ' ', tempArray, size);

	for (int i = 0; i<size; i++)
	{
		if (checkWords(tempArray[i]) == true)
		{
			counting[temp]++;
		}
		else
		{
			wording[index] = tempArray[i];
			counting[index]++;
			index++;
		}

	}

}

int WordCounts::getTally(string inputword)
{
	for (int i = 0; i<index; i++)
	{
		if (wording[i] == inputword)
		{
			return counting[i];
		}
	}
	return 0;
}

void WordCounts::resetTally()
{
	for (int i = 0; i<index; i++)
	{
		counting[i] = 0;
	}
}

void WordCounts::sortArray()
{
	int maximum = 0;
	int swapp;
	string swapper;

	for (int i = 0; i<10000; i++)
	{
		for (int j = 0; j<10000; j++)
		{
			maximum = counting[i];
			if (counting[j] < maximum)
			{
				swapp = counting[i];
				counting[i] = counting[j];
				counting[j] = swapp;

				swapper = wording[i];
				wording[i] = wording[j];
				wording[j] = swapper;
			}
		}
	}
}

int WordCounts::mostTimes(string words[], int count[], int n)
{
	sortArray();
	for (int i = 0; i<n; i++)
	{
		count[i] = counting[i];
	}

	for (int j = 0; j<n; j++)
	{
		words[j] = wording[j];
	}

	return n;
}
